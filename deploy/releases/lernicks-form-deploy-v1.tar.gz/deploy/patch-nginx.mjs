import { readFileSync, writeFileSync } from "node:fs";

const [sourcePath, outputPath] = process.argv.slice(2);
if (!sourcePath || !outputPath) {
  throw new Error("用法：node patch-nginx.mjs <现有配置> <新配置>");
}

const source = readFileSync(sourcePath, "utf8");
const marker = "# BEGIN lernicks application form";

if (source.includes(marker)) {
  writeFileSync(outputPath, source);
  process.exit(0);
}

const serverName = "server_name lernicks.cn www.lernicks.cn;";
const serverNameIndex = source.indexOf(serverName);
if (serverNameIndex < 0 || source.indexOf(serverName, serverNameIndex + serverName.length) >= 0) {
  throw new Error("没有唯一找到 lernicks.cn 主站配置，已停止修改。");
}

const insertionIndex = serverNameIndex + serverName.length;
const locations = `

    ${marker}
    location = /form {
        return 302 /form/;
    }

    location ^~ /form/ {
        proxy_pass http://127.0.0.1:1150/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Prefix /form;
    }

    location ^~ /_next/ {
        proxy_pass http://127.0.0.1:1150;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location = /favicon.svg {
        proxy_pass http://127.0.0.1:1150/favicon.svg;
        proxy_set_header Host $host;
    }

    location = /og-v2.png {
        proxy_pass http://127.0.0.1:1150/og-v2.png;
        proxy_set_header Host $host;
    }
    # END lernicks application form`;

writeFileSync(outputPath, source.slice(0, insertionIndex) + locations + source.slice(insertionIndex));

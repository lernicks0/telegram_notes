#!/usr/bin/env bash
set -Eeuo pipefail

if [[ "${EUID}" -ne 0 ]]; then
  echo "请使用 root 用户执行。" >&2
  exit 1
fi

APP_DIR="/root/form-site"
export NVM_DIR="/root/.nvm"

if [[ ! -s "$NVM_DIR/nvm.sh" ]]; then
  echo "未找到服务器现有的 nvm。" >&2
  exit 1
fi

source "$NVM_DIR/nvm.sh"
nvm install 22
nvm use 22

cd "$APP_DIR"
mkdir -p data
npm ci
chmod 700 deploy/start-form.sh

if pm2 describe application-form >/dev/null 2>&1; then
  pm2 restart application-form --update-env
else
  pm2 start "$APP_DIR/deploy/start-form.sh" \
    --name application-form \
    --interpreter bash \
    --cwd "$APP_DIR"
fi

for attempt in 1 2 3 4 5; do
  if curl -fsS http://127.0.0.1:1150/api/captcha -o /tmp/application-form-captcha.png; then
    break
  fi
  if [[ "$attempt" -eq 5 ]]; then
    pm2 logs application-form --lines 30 --nostream
    exit 1
  fi
  sleep 2
done

NGINX_LINK="/etc/nginx/sites-enabled/default"
NGINX_TARGET="$(readlink -f "$NGINX_LINK")"
if [[ -z "$NGINX_TARGET" || ! -f "$NGINX_TARGET" ]]; then
  echo "没有找到现有 Nginx 主配置，已停止。" >&2
  exit 1
fi

NGINX_BACKUP="/root/nginx-default-$(date +%Y%m%d-%H%M%S).bak"
NGINX_CANDIDATE="/tmp/nginx-default-with-form.conf"
node deploy/patch-nginx.mjs "$NGINX_TARGET" "$NGINX_CANDIDATE"
cp -a "$NGINX_TARGET" "$NGINX_BACKUP"
install -m 644 "$NGINX_CANDIDATE" "$NGINX_TARGET"

if nginx -t; then
  systemctl reload nginx
else
  install -m 644 "$NGINX_BACKUP" "$NGINX_TARGET"
  nginx -t
  echo "Nginx 检查失败，旧配置已经恢复。" >&2
  exit 1
fi

pm2 save
curl -fsS -o /dev/null -H "Host: sh.lernicks.cn" http://127.0.0.1/
echo "申请登记已部署到 https://sh.lernicks.cn/"

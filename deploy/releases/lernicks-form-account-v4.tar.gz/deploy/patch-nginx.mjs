import { readFileSync, writeFileSync } from "node:fs";

const [sourcePath, outputPath] = process.argv.slice(2);
if (!sourcePath || !outputPath) {
  throw new Error("用法：node patch-nginx.mjs <现有配置> <新配置>");
}

const source = readFileSync(sourcePath, "utf8");
const marker = "# BEGIN sh.lernicks.cn application form";

if (source.includes(marker)) {
  writeFileSync(outputPath, source);
  process.exit(0);
}

if (/server_name\s+[^;]*\bsh\.lernicks\.cn\b[^;]*;/.test(source)) {
  throw new Error("已经存在未由本安装程序管理的 sh.lernicks.cn 配置，已停止修改。");
}

const legacyBlock = /\r?\n[ \t]*# BEGIN lernicks application form[\s\S]*?[ \t]*# END lernicks application form\r?\n?/;
const cleanedSource = source.replace(legacyBlock, "\n").trimEnd();
const serverBlock = `

# This block is managed by the application-form deployment package.
${marker}
server {
    listen 80;
    server_name sh.lernicks.cn;

    location / {
        proxy_pass http://127.0.0.1:1150;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
# END sh.lernicks.cn application form`;

writeFileSync(outputPath, `${cleanedSource}${serverBlock}\n`);

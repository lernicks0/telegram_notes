#!/usr/bin/env bash
set -euo pipefail

export NVM_DIR="/root/.nvm"
source "$NVM_DIR/nvm.sh"
nvm use 22 >/dev/null

export FORM_DB_PATH="/root/form-site/data/applications.sqlite"
export NODE_ENV="production"

if [[ -f "/root/form-site/.env.auth" ]]; then
  set -a
  source "/root/form-site/.env.auth"
  set +a
fi

cd /root/form-site
exec npm run start -- --port 1150 --hostname 127.0.0.1

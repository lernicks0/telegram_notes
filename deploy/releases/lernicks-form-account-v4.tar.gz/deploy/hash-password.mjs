import { pbkdf2Sync, randomBytes } from "node:crypto";

let password = "";
for await (const chunk of process.stdin) password += chunk;
password = password.replace(/\r?\n$/, "");

if (password.length < 8 || password.length > 128) {
  process.stderr.write("密码长度需要为 8—128 个字符。\n");
  process.exit(1);
}

const iterations = 310_000;
const salt = randomBytes(16);
const digest = pbkdf2Sync(password, salt, iterations, 32, "sha256");
process.stdout.write(`pbkdf2_sha256$${iterations}$${salt.toString("base64")}$${digest.toString("base64")}`);

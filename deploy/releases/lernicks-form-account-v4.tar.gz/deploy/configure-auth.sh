#!/usr/bin/env bash
set -Eeuo pipefail

if [[ "${EUID}" -ne 0 ]]; then
  echo "请使用 root 用户执行。" >&2
  exit 1
fi

APP_DIR="/root/form-site"
ENV_FILE="$APP_DIR/.env.auth"
export NVM_DIR="/root/.nvm"

if [[ ! -s "$NVM_DIR/nvm.sh" ]]; then
  echo "未找到服务器现有的 nvm。" >&2
  exit 1
fi

read -r -s -p "设置审核后台密码（8—128 个字符）：" ADMIN_PASSWORD
echo
read -r -s -p "再次输入审核后台密码：" ADMIN_PASSWORD_CONFIRM
echo

if [[ "$ADMIN_PASSWORD" != "$ADMIN_PASSWORD_CONFIRM" ]]; then
  unset ADMIN_PASSWORD ADMIN_PASSWORD_CONFIRM
  echo "两次输入的密码不一致，未修改配置。" >&2
  exit 1
fi
if (( ${#ADMIN_PASSWORD} < 8 || ${#ADMIN_PASSWORD} > 128 )); then
  unset ADMIN_PASSWORD ADMIN_PASSWORD_CONFIRM
  echo "密码长度需要为 8—128 个字符，未修改配置。" >&2
  exit 1
fi

source "$NVM_DIR/nvm.sh"
nvm use 20 >/dev/null
PM2_NODE="$(command -v node)"
PM2_BIN="$(command -v pm2 || true)"
if [[ -z "$PM2_BIN" ]]; then
  unset ADMIN_PASSWORD ADMIN_PASSWORD_CONFIRM
  echo "没有在服务器现有的 Node 20 环境中找到 PM2，已停止。" >&2
  exit 1
fi

nvm use 22 >/dev/null
ADMIN_PASSWORD_HASH="$(printf '%s' "$ADMIN_PASSWORD" | node "$APP_DIR/deploy/hash-password.mjs")"
unset ADMIN_PASSWORD ADMIN_PASSWORD_CONFIRM

umask 077
printf "FORM_ADMIN_PASSWORD_HASH='%s'\n" "$ADMIN_PASSWORD_HASH" > "$ENV_FILE"
unset ADMIN_PASSWORD_HASH
chmod 600 "$ENV_FILE"

"$PM2_NODE" "$PM2_BIN" restart application-form --update-env
for attempt in 1 2 3 4 5; do
  if curl -fsS http://127.0.0.1:1150/api/captcha -o /tmp/application-form-captcha.png; then
    "$PM2_NODE" "$PM2_BIN" save
    echo "审核密码已设置，审核入口：https://sh.lernicks.cn/admin"
    exit 0
  fi
  sleep 2
done

"$PM2_NODE" "$PM2_BIN" logs application-form --lines 30 --nostream
echo "服务重启后未能通过健康检查，请查看上方日志。" >&2
exit 1

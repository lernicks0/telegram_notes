# 申请登记与审核

一个适合扫码填写的申请系统。申请人使用中国大陆手机号或邮箱注册账号，登录后提交表单，并在账号内查看审核结果与备注；审核后台使用独立密码登录。

## 功能

- 手机号或邮箱 + 密码注册、登录，不发送验证码
- 姓名、申请意图、申请原因、“做过什么坏事”等申请字段
- Steam 风格图片字符验证
- 申请人账号内查看“审核中 / 已通过 / 未通过”和审核备注
- 独立审核密码、审核列表和填写页二维码
- SQLite 持久化，升级部署时保留现有数据

## 本地开发

需要 Node.js `>=22.13.0`。

```bash
npm ci
npm run dev
npm run build
```

Node 自托管构建：

```bash
VINEXT_NODE_DEPLOY=1 npm run build
FORM_DB_PATH=./data/applications.sqlite npm run start -- --port 1150 --hostname 127.0.0.1
```

审核密码不保存明文。先生成 PBKDF2 哈希，再通过 `FORM_ADMIN_PASSWORD_HASH` 环境变量提供给服务。服务器部署包中的 `deploy/configure-auth.sh` 会以隐藏输入完成生成、保存和 PM2 重启。

## 服务器部署

部署包解压到 `/root/form-site` 后：

```bash
bash deploy/install-lernicks-form.sh
bash deploy/configure-auth.sh
```

- 数据库：`/root/form-site/data/applications.sqlite`
- 审核密码配置：`/root/form-site/.env.auth`（权限 `600`，不包含明文）
- 填写页：`https://sh.lernicks.cn/`
- 审核页：`https://sh.lernicks.cn/admin`

不要把 `.env.auth`、SQLite 数据库或真实账号信息提交到公开仓库。
